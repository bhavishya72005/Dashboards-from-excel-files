<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Analytics Dashboard & Excel Viewer</title>
  <meta name="description" content="Professional analytics dashboard with Excel bar chart and interactive data preview table.">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">

  <!-- Modular CSS (Pure CSS compatible with NetBeans 8.x validator) -->
  <link rel="stylesheet" type="text/css" href="css/style.css">

  <!-- SheetJS (Excel Parser) -->
  <script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>
</head>
<body>

<!-- ═══════════════════ WINDOW SHELL ═══════════════════ -->
<div class="window-shell">

  <!-- ── Title Bar ── -->
  <div class="title-bar">
    <div class="title-bar__dots">
      <div class="dot dot--red"    title="Close"></div>
      <div class="dot dot--yellow" title="Minimize"></div>
      <div class="dot dot--green"  title="Maximize"></div>
    </div>
    <span class="title-bar__title">A Window — PLAN</span>
    <span class="title-bar__badge">DRAFT</span>
  </div>

  <!-- ── Main Layout ── -->
  <div class="main-layout">

    <!-- ── Left Sidebar (hatched placeholder) ── -->
    <div class="sidebar-left">
      <div class="sidebar-left__hatch"></div>
      <div class="sidebar-left__label">Pending / Not Finalized</div>
    </div>

    <!-- ── Content Area ── -->
    <div class="content-area">

      <!-- ── Top Section ── -->
      <div class="top-section">

        <!-- ── Chart Card ── -->
        <div class="chart-card" id="chartCard">

          <!-- Header -->
          <div class="chart-card__header">
            <div class="chart-card__icon">📊</div>
            <span class="chart-card__title">Excel Data — Bar Chart</span>
            <span class="chart-card__subtitle" id="chartSubtitle">No data loaded</span>
          </div>

          <!-- Loading Overlay -->
          <div class="loading-overlay" id="loadingOverlay">
            <div class="loader-ring">
              <svg viewBox="0 0 64 64">
                <circle cx="32" cy="32" r="28"/>
                <circle cx="32" cy="32" r="18"/>
              </svg>
            </div>
            <span class="loading-text">Processing Excel file…</span>
            <div class="loading-dots">
              <span></span><span></span><span></span>
            </div>
          </div>

          <!-- Chart Viewport -->
          <div class="chart-viewport" id="chartViewport">

            <!-- Empty State -->
            <div class="chart-empty" id="chartEmpty">
              <div class="chart-empty__icon">📂</div>
              <div class="chart-empty__title">No Data Yet</div>
              <div class="chart-empty__sub">
                Upload an Excel (.xlsx / .xls) or CSV file to visualize your data as a bar chart.
              </div>
              <div class="chart-empty__pulse"></div>
            </div>

            <!-- Fixed Y-Axis Scale (Permanently pinned on the left while chart scrolls horizontally) -->
            <div class="chart-y-axis-fixed" id="chartYAxisFixed" style="display:none;">
              <canvas id="yAxisCanvas"></canvas>
            </div>

            <!-- Scrollable Chart Wrapper -->
            <div class="chart-scroll" id="chartScroll" style="display:none;">
              <div class="chart-inner" id="chartInner">
                <canvas id="barChart"></canvas>
              </div>
            </div>

          </div>

          <!-- Legend -->
          <div class="chart-legend" id="chartLegend" style="display:none;"></div>

        </div>
        <!-- /chart-card -->

        <!-- ── Upload Panel ── -->
        <div class="upload-panel">

          <div class="upload-panel__title">
            <span class="status-dot"></span>
            Upload Excel
          </div>

          <!-- Drop Zone -->
          <div class="drop-zone" id="dropZone">
            <input type="file" id="fileInput" accept=".xlsx,.xls,.csv" multiple>
            <div class="drop-zone__icon">📤</div>
            <div class="drop-zone__text">
              Drag &amp; drop or<br>
              <strong>click to browse</strong>
            </div>
            <div class="drop-zone__ext">.xlsx &nbsp;·&nbsp; .xls &nbsp;·&nbsp; .csv</div>
          </div>

          <!-- Upload History -->
          <div class="upload-history" id="uploadHistory">
            <div class="upload-history__label">History Files</div>
            <div id="fileList" style="display:flex;flex-direction:column;gap:6px;"></div>
          </div>

          <!-- Stats Strip -->
          <div class="stats-strip" id="statsStrip" style="display:none;">
            <div class="stat-row">
              <span class="stat-row__key">Rows</span>
              <span class="stat-row__val" id="statRows">—</span>
            </div>
            <div class="stat-row">
              <span class="stat-row__key">Cols</span>
              <span class="stat-row__val" id="statCols">—</span>
            </div>
            <div class="stat-row">
              <span class="stat-row__key">Files</span>
              <span class="stat-row__val" id="statFiles">0</span>
            </div>
          </div>

        </div>
        <!-- /upload-panel -->

      </div>
      <!-- /top-section -->

      <!-- ── Bottom Section (blue placeholder) ── -->
      <div class="bottom-section">
        <div class="orb" style="width:80px;height:80px;background:radial-gradient(circle,#4cc9f0,transparent);left:8%;top:-20%;animation-duration:5s;"></div>
        <div class="orb" style="width:50px;height:50px;background:radial-gradient(circle,#7209b7,transparent);left:35%;top:10%;animation-duration:7s;animation-delay:-2s;"></div>
        <div class="orb" style="width:100px;height:100px;background:radial-gradient(circle,#4361ee,transparent);left:60%;top:-30%;animation-duration:6s;animation-delay:-1s;"></div>
        <div class="orb" style="width:40px;height:40px;background:radial-gradient(circle,#06d6a0,transparent);left:85%;top:5%;animation-duration:4.5s;animation-delay:-3s;"></div>
        <div class="bottom-label">Reserved — Not Yet Finalized</div>
      </div>

    </div>
    <!-- /content-area -->

  </div>
  <!-- /main-layout -->

</div>
<!-- /window-shell -->

<!-- Toast Notification -->
<div class="toast" id="toast">
  <span class="toast__icon" id="toastIcon">✅</span>
  <span id="toastMsg">File loaded!</span>
</div>

<!-- ═══════════════════ EXCEL DATA PREVIEW MULTI-WINDOW CONTAINER ═══════════════════ -->
<!-- Non-blocking container: allows full background interaction while multiple windows can open & stack -->
<div class="data-windows-container" id="dataWindowsContainer"></div>

<!-- Modular JavaScript for NetBeans 8.x -->
<script src="js/app.js"></script>

</body>
</html>
