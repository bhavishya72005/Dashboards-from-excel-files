/**
 * Analytics Dashboard & Excel Viewer
 * Compatible with NetBeans 8.x
 */

// Color palette for chart series
var PALETTE = [
  { bg: 'rgba(67,97,238,0.82)',   border: '#4361ee' },
  { bg: 'rgba(76,201,240,0.82)',  border: '#4cc9f0' },
  { bg: 'rgba(6,214,160,0.82)',   border: '#06d6a0' },
  { bg: 'rgba(247,127,0,0.82)',   border: '#f77f00' },
  { bg: 'rgba(224,64,251,0.82)',  border: '#e040fb' },
  { bg: 'rgba(114,9,183,0.82)',   border: '#7209b7' },
  { bg: 'rgba(251,86,7,0.82)',    border: '#fb5607' },
  { bg: 'rgba(255,209,102,0.82)', border: '#ffd166' },
  { bg: 'rgba(239,35,60,0.82)',   border: '#ef233c' },
  { bg: 'rgba(131,56,236,0.82)',  border: '#8338ec' }
];

// SVG Icon definitions for Eye (Open) and Eye (Hide / Slashed)
var SVG_EYE_OPEN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
  '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>' +
  '<circle cx="12" cy="12" r="3"></circle>' +
  '</svg>';

var SVG_EYE_HIDE = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
  '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>' +
  '<line x1="1" y1="1" x2="23" y2="23"></line>' +
  '</svg>';

// Application State
var chartInstance       = null;
var uploadedFiles       = [];
var activeFileIndex     = -1;
var openWindows         = {}; // Map of fileIndex -> windowState
var globalTopZIndex     = 1000;
var MODAL_SCALES        = [
  { w: '580px', h: '400px', name: 'Compact' },
  { w: '740px', h: '490px', name: 'Default' },
  { w: '920px', h: '620px', name: 'Expanded' }
];

// DOM Element References
var fileInput             = document.getElementById('fileInput');
var dropZone              = document.getElementById('dropZone');
var fileList              = document.getElementById('fileList');
var chartEmpty            = document.getElementById('chartEmpty');
var chartYAxisFixed       = document.getElementById('chartYAxisFixed');
var yAxisCanvas           = document.getElementById('yAxisCanvas');
var chartScroll           = document.getElementById('chartScroll');
var chartInner            = document.getElementById('chartInner');
var chartLegend           = document.getElementById('chartLegend');
var loadingOverlay        = document.getElementById('loadingOverlay');
var chartSubtitle         = document.getElementById('chartSubtitle');
var statsStrip            = document.getElementById('statsStrip');
var statRows              = document.getElementById('statRows');
var statCols              = document.getElementById('statCols');
var statFiles             = document.getElementById('statFiles');
var toastEl               = document.getElementById('toast');
var toastMsg              = document.getElementById('toastMsg');
var toastIcon             = document.getElementById('toastIcon');
var dataWindowsContainer  = document.getElementById('dataWindowsContainer');

/* ─── Toast System ────────────────────────────────────────── */
var toastTimer = null;
function showToast(msg, icon) {
  icon = icon || '✅';
  toastMsg.textContent = msg;
  toastIcon.textContent = icon;
  toastEl.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function() {
    toastEl.classList.remove('show');
  }, 3200);
}

/* ─── Drag & Drop Listeners ───────────────────────────────── */
if (dropZone) {
  dropZone.addEventListener('dragover', function(e) {
    e.preventDefault();
    dropZone.classList.add('drag-over');
  });

  dropZone.addEventListener('dragleave', function() {
    dropZone.classList.remove('drag-over');
  });

  dropZone.addEventListener('drop', function(e) {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    handleFiles(e.dataTransfer.files);
  });
}

if (fileInput) {
  fileInput.addEventListener('change', function(e) {
    handleFiles(e.target.files);
  });
}

/* ─── Handle Uploaded Files ───────────────────────────────── */
function handleFiles(files) {
  if (!files || files.length === 0) return;
  for (var i = 0; i < files.length; i++) {
    readExcelFile(files[i]);
  }
  fileInput.value = '';
}

/* ─── Read & Parse Excel / CSV via SheetJS ────────────────── */
function readExcelFile(file) {
  showLoading(true);
  var reader = new FileReader();

  reader.onload = function(e) {
    setTimeout(function() {
      try {
        var data = new Uint8Array(e.target.result);
        var wb = XLSX.read(data, { type: 'array' });
        var wsName = wb.SheetNames[0];
        var ws = wb.Sheets[wsName];
        var jsonData = XLSX.utils.sheet_to_json(ws, { defval: '' });

        var entry = {
          name: file.name,
          size: file.size,
          sheet: wsName,
          rows: jsonData
        };

        var newIndex = uploadedFiles.length;
        uploadedFiles.push(entry);

        refreshFileList();
        renderChart(entry, newIndex);
        showLoading(false);
        showToast('"' + file.name + '" loaded (' + jsonData.length + ' rows)', '✅');
      } catch (err) {
        showLoading(false);
        showToast('Could not parse file. Verify format.', '⚠️');
        console.error(err);
      }
    }, 700);
  };

  reader.readAsArrayBuffer(file);
}

function showLoading(on) {
  if (loadingOverlay) {
    if (on) {
      loadingOverlay.classList.add('active');
    } else {
      loadingOverlay.classList.remove('active');
    }
  }
}

/* ─── Render Uploaded Files History List ──────────────────── */
function refreshFileList() {
  if (!fileList) return;
  fileList.innerHTML = '';

  for (var i = 0; i < uploadedFiles.length; i++) {
    (function(idx) {
      var item = uploadedFiles[idx];
      var div = document.createElement('div');
      div.className = 'file-item' + (idx === activeFileIndex ? ' active' : '');
      div.id = 'file-item-' + idx;

      // Icon
      var icon = document.createElement('span');
      icon.className = 'file-item__icon';
      icon.textContent = '📊';

      // Name & Size
      var infoBox = document.createElement('div');
      infoBox.className = 'file-item__info';

      var nameSpan = document.createElement('span');
      nameSpan.className = 'file-item__name';
      nameSpan.textContent = item.name;
      nameSpan.title = item.name;

      var sizeSpan = document.createElement('span');
      sizeSpan.className = 'file-item__size';
      sizeSpan.textContent = formatBytes(item.size);

      infoBox.appendChild(nameSpan);
      infoBox.appendChild(sizeSpan);

      // Eye button for data preview
      var isWinOpen = !!openWindows[idx];
      var eyeBtn = document.createElement('button');
      eyeBtn.type = 'button';
      eyeBtn.className = 'file-item__eye' + (isWinOpen ? ' active' : '');
      eyeBtn.title = isWinOpen ? 'Close table preview' : 'View Excel rows & columns';
      eyeBtn.innerHTML = isWinOpen ? SVG_EYE_HIDE : SVG_EYE_OPEN;

      // Eye Click: Toggle Modal Preview
      eyeBtn.addEventListener('click', function(ev) {
        ev.stopPropagation(); // prevent triggering row select
        toggleDataModal(idx);
      });

      // Item Row Click: Switch Active Chart
      div.addEventListener('click', function() {
        renderChart(item, idx);
      });

      div.appendChild(icon);
      div.appendChild(infoBox);
      div.appendChild(eyeBtn);

      fileList.appendChild(div);
    })(i);
  }

  if (statsStrip) {
    statsStrip.style.display = uploadedFiles.length > 0 ? 'flex' : 'none';
  }
  if (statFiles) {
    statFiles.textContent = uploadedFiles.length;
  }
}

/* ─── Multi-Window Excel Preview System ───────────────────── */

// Helper to sanitize HTML strings
function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Bring a window to the top-most z-index
function bringWindowToFront(idx) {
  var winState = openWindows[idx];
  if (!winState) return;

  globalTopZIndex++;
  winState.element.style.zIndex = globalTopZIndex;

  // Visual active highlight
  var allModals = document.querySelectorAll('.data-modal');
  for (var i = 0; i < allModals.length; i++) {
    allModals[i].classList.remove('active-window');
  }
  winState.element.classList.add('active-window');
}

// Toggle a specific file's preview window
function toggleDataModal(idx) {
  if (openWindows[idx]) {
    closeDataModal(idx);
  } else {
    openDataModal(idx);
  }
}

// Open a file preview window (stacked on top of others)
function openDataModal(idx) {
  var fileData = uploadedFiles[idx];
  if (!fileData) return;

  // If already open, bring to front
  if (openWindows[idx]) {
    bringWindowToFront(idx);
    showToast('Focused: ' + fileData.name, '📑');
    return;
  }

  // Create Window Element
  var winDiv = document.createElement('div');
  winDiv.className = 'data-modal active-window';
  winDiv.id = 'dataModalWindow_' + idx;
  winDiv.setAttribute('data-file-index', idx);

  winDiv.innerHTML =
    '<div class="data-modal__header" data-drag-header="true" title="Click &amp; drag header to move window">' +
      '<div class="data-modal__drag-handle" title="Click and drag to move preview window">' +
        '<svg width="12" height="18" viewBox="0 0 12 18" fill="currentColor">' +
          '<circle cx="3" cy="3" r="1.5"/><circle cx="9" cy="3" r="1.5"/>' +
          '<circle cx="3" cy="9" r="1.5"/><circle cx="9" cy="9" r="1.5"/>' +
          '<circle cx="3" cy="15" r="1.5"/><circle cx="9" cy="15" r="1.5"/>' +
        '</svg>' +
      '</div>' +
      '<div class="data-modal__icon">📑</div>' +
      '<div class="data-modal__title-box">' +
        '<span class="data-modal__title" title="' + escapeHtml(fileData.name) + '">' + escapeHtml(fileData.name) + '</span>' +
        '<span class="data-modal__sheet-pill">Sheet: ' + escapeHtml(fileData.sheet) + '</span>' +
        '<span class="data-modal__drag-indicator" title="Window is draggable — click and drag header to move">✥ Drag to move</span>' +
      '</div>' +
      '<div class="data-modal__controls">' +
        '<button type="button" class="modal-btn modal-btn--reset" data-action="reset" title="Reset Window Position (Center)">⟲</button>' +
        '<button type="button" class="modal-btn modal-btn--scale" data-action="scale" title="Scale Window (Compact / Default / Expanded)">🔍</button>' +
        '<button type="button" class="modal-btn modal-btn--max" data-action="maximize" title="Maximize Window">🗖</button>' +
        '<button type="button" class="modal-btn modal-btn--close" data-action="close" title="Close Preview">✕</button>' +
      '</div>' +
    '</div>' +
    '<div class="data-modal__toolbar">' +
      '<div class="modal-search">' +
        '<span class="modal-search__icon">🔍</span>' +
        '<input type="text" class="modal-search-input" placeholder="Filter rows across all columns…">' +
      '</div>' +
      '<span class="data-modal__counts">0 rows</span>' +
    '</div>' +
    '<div class="data-modal__content">' +
      '<table class="data-grid">' +
        '<thead></thead>' +
        '<tbody></tbody>' +
      '</table>' +
    '</div>' +
    '<div class="data-modal__footer">' +
      '<span class="modal-footer-info">Showing rows · Scalable Window</span>' +
      '<span class="data-modal__resize-hint">✥ Drag header to move · ↘ Drag corner to resize</span>' +
    '</div>';

  var winState = {
    element: winDiv,
    fileIndex: idx,
    isMaximized: false,
    scaleIndex: 1,
    lastLeft: 0,
    lastTop: 0,
    tableHead: winDiv.querySelector('thead'),
    tableBody: winDiv.querySelector('tbody'),
    rowCountEl: winDiv.querySelector('.data-modal__counts'),
    footerInfoEl: winDiv.querySelector('.modal-footer-info'),
    searchInput: winDiv.querySelector('.modal-search-input'),
    maxBtn: winDiv.querySelector('[data-action="maximize"]'),
    scaleBtn: winDiv.querySelector('[data-action="scale"]'),
    resetBtn: winDiv.querySelector('[data-action="reset"]'),
    closeBtn: winDiv.querySelector('[data-action="close"]'),
    headerEl: winDiv.querySelector('.data-modal__header')
  };

  // Calculate Cascade Position so windows stack one on top of each other
  var openKeys = Object.keys(openWindows);
  var openCount = openKeys.length;
  var cascadeStep = 28;
  var offset = (openCount % 7) * cascadeStep;

  var defaultW = 740;
  var defaultH = 480;
  var initLeft = Math.max(16, Math.round((window.innerWidth - defaultW) / 2) + offset - 60);
  var initTop = Math.max(16, Math.round((window.innerHeight - defaultH) / 2) + offset - 40);

  // Bounds clamp
  initLeft = Math.max(10, Math.min(initLeft, window.innerWidth - 300));
  initTop = Math.max(10, Math.min(initTop, window.innerHeight - 150));

  winDiv.style.left = initLeft + 'px';
  winDiv.style.top = initTop + 'px';
  winDiv.style.width = MODAL_SCALES[1].w;
  winDiv.style.height = MODAL_SCALES[1].h;

  globalTopZIndex++;
  winDiv.style.zIndex = globalTopZIndex;

  winState.lastLeft = initLeft;
  winState.lastTop = initTop;

  // Window Focus on Click
  winDiv.addEventListener('mousedown', function() {
    bringWindowToFront(idx);
  });
  winDiv.addEventListener('touchstart', function() {
    bringWindowToFront(idx);
  }, { passive: true });

  // Control Buttons
  winState.closeBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    closeDataModal(idx);
  });

  winState.resetBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    resetWindowPosition(winState);
  });

  winState.scaleBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    cycleScale(winState);
  });

  winState.maxBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    toggleMaximize(winState);
  });

  // Search Filter
  winState.searchInput.addEventListener('input', function(e) {
    renderPreviewTable(winState, e.target.value);
  });

  // Header Dragging
  winState.headerEl.addEventListener('mousedown', function(e) {
    if (e.target.closest('button') || e.target.closest('input')) return;
    if (e.button !== 0) return;
    if (winState.isMaximized) return;

    e.preventDefault();
    bringWindowToFront(idx);
    startModalDrag(winState, e.clientX, e.clientY);
  });

  winState.headerEl.addEventListener('dblclick', function(e) {
    if (e.target.closest('button') || e.target.closest('input')) return;
    toggleMaximize(winState);
  });

  winState.headerEl.addEventListener('touchstart', function(e) {
    if (e.target.closest('button') || e.target.closest('input')) return;
    if (e.touches && e.touches.length === 1) {
      bringWindowToFront(idx);
      startModalDrag(winState, e.touches[0].clientX, e.touches[0].clientY);
    }
  }, { passive: true });

  // Populate data table
  renderPreviewTable(winState, '');

  // Add to DOM
  if (dataWindowsContainer) {
    dataWindowsContainer.appendChild(winDiv);
  }
  openWindows[idx] = winState;

  // Update eye buttons in history
  refreshFileList();
  showToast('Opened preview: ' + fileData.name, '📑');
}

// Close a specific preview window
function closeDataModal(idx) {
  var winState = openWindows[idx];
  if (!winState) return;

  var fileName = uploadedFiles[idx] ? uploadedFiles[idx].name : '';
  if (winState.element && winState.element.parentNode) {
    winState.element.parentNode.removeChild(winState.element);
  }
  delete openWindows[idx];

  refreshFileList();
  if (fileName) {
    showToast('Closed preview: ' + fileName, '✕');
  }
}

// Render Table Rows for a specific window
function renderPreviewTable(winState, filterText) {
  var fileData = uploadedFiles[winState.fileIndex];
  if (!fileData) return;

  var rows = fileData.rows;
  winState.tableHead.innerHTML = '';
  winState.tableBody.innerHTML = '';

  if (!rows || rows.length === 0) {
    winState.tableBody.innerHTML = '<tr><td colspan="4" style="text-align:center;padding:24px;color:#94a3b8;">No data records found in this sheet.</td></tr>';
    winState.rowCountEl.textContent = '0 rows';
    winState.footerInfoEl.textContent = 'Sheet is empty';
    return;
  }

  var columns = Object.keys(rows[0]);
  var headerTr = document.createElement('tr');

  var thIdx = document.createElement('th');
  thIdx.className = 'col-index';
  thIdx.textContent = '#';
  headerTr.appendChild(thIdx);

  for (var c = 0; c < columns.length; c++) {
    var th = document.createElement('th');
    th.textContent = columns[c];
    headerTr.appendChild(th);
  }
  winState.tableHead.appendChild(headerTr);

  var query = (filterText || '').trim().toLowerCase();
  var filteredRows = [];

  for (var r = 0; r < rows.length; r++) {
    var rowObj = rows[r];
    if (!query) {
      filteredRows.push({ originalIndex: r + 1, data: rowObj });
    } else {
      var match = false;
      for (var colIdx = 0; colIdx < columns.length; colIdx++) {
        var cellVal = String(rowObj[columns[colIdx]] || '').toLowerCase();
        if (cellVal.indexOf(query) !== -1) {
          match = true;
          break;
        }
      }
      if (match) {
        filteredRows.push({ originalIndex: r + 1, data: rowObj });
      }
    }
  }

  var maxPreviewRows = 500;
  var renderCount = Math.min(filteredRows.length, maxPreviewRows);

  for (var i = 0; i < renderCount; i++) {
    var item = filteredRows[i];
    var tr = document.createElement('tr');

    var tdIdx = document.createElement('td');
    tdIdx.className = 'cell-index';
    tdIdx.textContent = item.originalIndex;
    tr.appendChild(tdIdx);

    for (var j = 0; j < columns.length; j++) {
      var td = document.createElement('td');
      var val = item.data[columns[j]];
      var isNum = typeof val === 'number' || (!isNaN(parseFloat(val)) && isFinite(val) && String(val).trim() !== '');

      if (isNum) {
        td.className = 'cell-num';
      }
      td.textContent = (val !== undefined && val !== null) ? val : '';
      tr.appendChild(td);
    }

    winState.tableBody.appendChild(tr);
  }

  if (query) {
    winState.rowCountEl.textContent = filteredRows.length + ' of ' + rows.length + ' rows';
  } else {
    winState.rowCountEl.textContent = rows.length + ' rows, ' + columns.length + ' columns';
  }

  winState.footerInfoEl.textContent = 'Showing ' + renderCount + ' of ' + filteredRows.length + ' rows · Scalable Window';
}

// Window actions
function cycleScale(winState) {
  if (winState.isMaximized) {
    toggleMaximize(winState);
  }
  winState.scaleIndex = (winState.scaleIndex + 1) % MODAL_SCALES.length;
  var scale = MODAL_SCALES[winState.scaleIndex];
  winState.element.style.width = scale.w;
  winState.element.style.height = scale.h;
  showToast('Window scaled: ' + scale.name, '🔍');
}

function toggleMaximize(winState) {
  winState.isMaximized = !winState.isMaximized;
  if (winState.isMaximized) {
    winState.element.classList.add('maximized');
    winState.maxBtn.title = 'Restore Window';
    winState.maxBtn.textContent = '❐';
  } else {
    winState.element.classList.remove('maximized');
    var scale = MODAL_SCALES[winState.scaleIndex];
    winState.element.style.width = scale.w;
    winState.element.style.height = scale.h;
    winState.maxBtn.title = 'Maximize';
    winState.maxBtn.textContent = '🗖';
    if (winState.lastLeft !== undefined && winState.lastTop !== undefined) {
      winState.element.style.left = winState.lastLeft + 'px';
      winState.element.style.top = winState.lastTop + 'px';
    }
  }
}

function resetWindowPosition(winState) {
  var w = winState.element.offsetWidth || 740;
  var h = winState.element.offsetHeight || 480;
  var centerLeft = Math.max(20, Math.round((window.innerWidth - w) / 2));
  var centerTop = Math.max(20, Math.round((window.innerHeight - h) / 2));
  winState.element.style.left = centerLeft + 'px';
  winState.element.style.top = centerTop + 'px';
  winState.lastLeft = centerLeft;
  winState.lastTop = centerTop;
  showToast('Window re-centered: ' + uploadedFiles[winState.fileIndex].name, '🎯');
}

/* ─── Multi-Window Dragging Mechanics ────────────────────── */
var isDraggingModal  = false;
var activeDragWindow = null;
var dragStartX       = 0;
var dragStartY       = 0;
var initialModalLeft = 0;
var initialModalTop  = 0;

function startModalDrag(winState, clientX, clientY) {
  if (winState.isMaximized) return;

  var rect = winState.element.getBoundingClientRect();
  isDraggingModal = true;
  activeDragWindow = winState;
  dragStartX = clientX;
  dragStartY = clientY;
  initialModalLeft = rect.left;
  initialModalTop = rect.top;

  winState.element.style.left = rect.left + 'px';
  winState.element.style.top = rect.top + 'px';

  winState.element.classList.add('is-dragging');
  document.body.classList.add('modal-dragging');
}

function moveModalDrag(clientX, clientY) {
  if (!isDraggingModal || !activeDragWindow) return;

  var deltaX = clientX - dragStartX;
  var deltaY = clientY - dragStartY;

  var newLeft = initialModalLeft + deltaX;
  var newTop = initialModalTop + deltaY;

  var modalWidth = activeDragWindow.element.offsetWidth;
  var viewportWidth = window.innerWidth;
  var viewportHeight = window.innerHeight;

  var minLeft = -(modalWidth - 120);
  var maxLeft = viewportWidth - 120;
  var minTop = 0;
  var maxTop = Math.max(0, viewportHeight - 48);

  newLeft = Math.max(minLeft, Math.min(newLeft, maxLeft));
  newTop = Math.max(minTop, Math.min(newTop, maxTop));

  activeDragWindow.element.style.left = newLeft + 'px';
  activeDragWindow.element.style.top = newTop + 'px';

  activeDragWindow.lastLeft = newLeft;
  activeDragWindow.lastTop = newTop;
}

function endModalDrag() {
  if (!isDraggingModal) return;
  if (activeDragWindow) {
    activeDragWindow.element.classList.remove('is-dragging');
  }
  document.body.classList.remove('modal-dragging');
  isDraggingModal = false;
  activeDragWindow = null;
}

// Global Move and Up Listeners
document.addEventListener('mousemove', function(e) {
  if (isDraggingModal) {
    e.preventDefault();
    moveModalDrag(e.clientX, e.clientY);
  }
});

document.addEventListener('mouseup', function() {
  if (isDraggingModal) {
    endModalDrag();
  }
});

document.addEventListener('touchmove', function(e) {
  if (isDraggingModal && e.touches && e.touches.length === 1) {
    var touch = e.touches[0];
    moveModalDrag(touch.clientX, touch.clientY);
  }
}, { passive: true });

document.addEventListener('touchend', function() {
  if (isDraggingModal) {
    endModalDrag();
  }
});

document.addEventListener('touchcancel', function() {
  if (isDraggingModal) {
    endModalDrag();
  }
});

// Close front-most window on Escape
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    var keys = Object.keys(openWindows);
    if (keys.length > 0) {
      var topIdx = -1;
      var maxZ = -1;
      keys.forEach(function(k) {
        var z = parseInt(openWindows[k].element.style.zIndex, 10) || 0;
        if (z > maxZ) {
          maxZ = z;
          topIdx = parseInt(k, 10);
        }
      });
      if (topIdx !== -1) {
        closeDataModal(topIdx);
      }
    }
  }
});

// Clamp windows on browser resize
window.addEventListener('resize', function() {
  var keys = Object.keys(openWindows);
  keys.forEach(function(k) {
    var win = openWindows[k];
    if (win && !win.isMaximized) {
      var rect = win.element.getBoundingClientRect();
      var maxL = Math.max(10, window.innerWidth - 120);
      var maxT = Math.max(0, window.innerHeight - 48);

      if (rect.left > maxL) {
        win.element.style.left = maxL + 'px';
        win.lastLeft = maxL;
      }
      if (rect.top > maxT) {
        win.element.style.top = maxT + 'px';
        win.lastTop = maxT;
      }
    }
  });
});

/* ─── Fixed Y-Axis Scale Renderer ─────────────────────────── */
function syncFixedYAxis(chart) {
  var fixedCanvas = document.getElementById('yAxisCanvas');
  if (!fixedCanvas || !chart || !chart.scales || !chart.scales.y) return;

  var yScale = chart.scales.y;
  var chartArea = chart.chartArea;
  if (!chartArea) return;

  var ticks = yScale.ticks || [];
  if (ticks.length === 0) return;

  // Measure formatted tick widths to dynamically allocate space
  var tempCanvas = document.createElement('canvas');
  var tempCtx = tempCanvas.getContext('2d');
  tempCtx.font = '11px Inter, sans-serif';

  var formattedLabels = [];
  var maxTextW = 30;

  for (var i = 0; i < ticks.length; i++) {
    var tick = ticks[i];
    var label = tick.label;
    if (label === undefined || label === null || label === '') {
      if (typeof yScale.getLabelForValue === 'function') {
        label = yScale.getLabelForValue(tick.value);
      } else {
        label = typeof tick.value === 'number' ? tick.value.toLocaleString() : String(tick.value);
      }
    }
    formattedLabels.push(label);
    var measuredW = tempCtx.measureText(label).width;
    if (measuredW > maxTextW) {
      maxTextW = measuredW;
    }
  }

  var viewport = document.getElementById('chartViewport');
  var maxAllowedW = viewport ? Math.floor(viewport.clientWidth * 0.35) : 220;
  // Ensure generous breathing room: 16px left margin + max text width + 10px right margin
  var cssW = Math.max(65, Math.min(Math.ceil(maxTextW + 28), maxAllowedW));
  var cssH = chart.height;

  // Sync fixed container width according to available space
  if (chartYAxisFixed) {
    chartYAxisFixed.style.width = cssW + 'px';
    chartYAxisFixed.style.minWidth = cssW + 'px';
  }

  var dpr = window.devicePixelRatio || 1;
  fixedCanvas.width = Math.round(cssW * dpr);
  fixedCanvas.height = Math.round(cssH * dpr);
  fixedCanvas.style.width = cssW + 'px';
  fixedCanvas.style.height = cssH + 'px';

  var ctx = fixedCanvas.getContext('2d');
  ctx.save();
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, cssW, cssH);

  // Vertical dividing axis line between fixed scale and scrollable bars
  ctx.strokeStyle = 'rgba(0,0,0,0.15)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(cssW - 0.5, chartArea.top);
  ctx.lineTo(cssW - 0.5, chartArea.bottom);
  ctx.stroke();

  // Ticks and labels
  ctx.font = '11px Inter, sans-serif';
  ctx.fillStyle = '#475569';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';

  for (var j = 0; j < ticks.length; j++) {
    var yPos = yScale.getPixelForTick(j);

    // Skip if out of chart area bounds
    if (yPos < chartArea.top - 2 || yPos > chartArea.bottom + 2) continue;

    // Little tick mark pointing right into the chart grid line
    ctx.strokeStyle = 'rgba(0,0,0,0.22)';
    ctx.beginPath();
    ctx.moveTo(cssW - 5, yPos);
    ctx.lineTo(cssW - 0.5, yPos);
    ctx.stroke();

    // Value label with guaranteed spacing from the left
    ctx.fillText(formattedLabels[j], cssW - 10, yPos);
  }

  // Draw small "VALUE" indicator at the top of the fixed axis
  if (chartArea.top >= 14) {
    ctx.font = '600 9px Outfit, Inter, sans-serif';
    ctx.fillStyle = '#4361ee';
    ctx.textAlign = 'right';
    ctx.fillText('VALUE', cssW - 10, chartArea.top - 8);
  }

  ctx.restore();
}

// Mouse wheel horizontal scroll on chart
if (chartScroll) {
  chartScroll.addEventListener('wheel', function(e) {
    if (e.deltaY !== 0 && !e.shiftKey) {
      e.preventDefault();
      chartScroll.scrollLeft += e.deltaY;
    }
  }, { passive: false });
}

/* ─── Render Bar Chart ────────────────────────────────────── */
function renderChart(entry, idx) {
  activeFileIndex = idx;
  refreshFileList();

  var rows = entry.rows;
  if (!rows || rows.length === 0) {
    showToast('No rows found in sheet.', '⚠️');
    return;
  }

  var columns = Object.keys(rows[0]);
  if (columns.length < 2) {
    showToast('Need at least 2 columns (label + value).', '⚠️');
    return;
  }

  var labelCol = columns[0];
  var valueCols = columns.slice(1);
  var labels = rows.map(function(r) { return String(r[labelCol] || ''); });

  var maxVal = 0;
  var datasets = valueCols.map(function(col, ci) {
    var colour = PALETTE[ci % PALETTE.length];
    return {
      label: col,
      data: rows.map(function(r) {
        var num = parseFloat(r[col]) || 0;
        if (num > maxVal) maxVal = num;
        return num;
      }),
      backgroundColor: colour.bg,
      borderColor: colour.border,
      borderWidth: 2,
      borderRadius: 6,
      borderSkipped: false
    };
  });

  // Estimate required Y-axis width from maximum value to allocate sufficient space upfront
  var tempCanvas = document.createElement('canvas');
  var tempCtx = tempCanvas.getContext('2d');
  tempCtx.font = '11px Inter, sans-serif';
  var estMaxTextW = tempCtx.measureText(maxVal.toLocaleString()).width;
  var estAxisW = Math.max(65, Math.ceil(estMaxTextW + 28));

  if (chartYAxisFixed) {
    chartYAxisFixed.style.width = estAxisW + 'px';
    chartYAxisFixed.style.minWidth = estAxisW + 'px';
  }

  // Dynamic canvas sizing
  var viewport = document.getElementById('chartViewport');
  var minPerBar = 54 * valueCols.length;
  var viewportAvailW = viewport ? (viewport.clientWidth - (estAxisW + 15)) : 600;
  var canvasW = Math.max(viewportAvailW, labels.length * minPerBar);
  var canvasH = viewport ? (viewport.clientHeight - 30) : 400;

  chartEmpty.style.display = 'none';
  if (chartYAxisFixed) chartYAxisFixed.style.display = 'flex';
  chartScroll.style.display = 'block';
  chartInner.style.width = canvasW + 'px';
  chartInner.style.height = canvasH + 'px';

  var canvas = document.getElementById('barChart');
  canvas.width = canvasW;
  canvas.height = canvasH;

  if (chartInstance) {
    chartInstance.destroy();
    chartInstance = null;
  }

  chartInstance = new Chart(canvas, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: datasets
    },
    options: {
      responsive: false,
      maintainAspectRatio: false,
      layout: {
        padding: {
          top: 16,
          right: 20,
          bottom: 6,
          left: 0
        }
      },
      animation: {
        duration: 800,
        easing: 'easeOutQuart'
      },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: 'rgba(255,255,255,0.97)',
          borderColor: 'rgba(67,97,238,0.35)',
          borderWidth: 1,
          titleColor: '#4361ee',
          bodyColor: '#334155',
          padding: 10,
          cornerRadius: 8,
          callbacks: {
            label: function(ctx) {
              return ' ' + ctx.dataset.label + ': ' + ctx.parsed.y.toLocaleString();
            }
          }
        }
      },
      scales: {
        x: {
          grid: { color: 'rgba(0,0,0,0.06)' },
          ticks: { color: '#334155', font: { size: 11 }, maxRotation: 45, minRotation: 0 },
          border: { color: 'rgba(0,0,0,0.15)' },
          title: {
            display: true,
            text: labelCol,
            color: '#1e293b',
            font: { size: 12, weight: '600' },
            padding: { top: 6 }
          }
        },
        y: {
          position: 'left',
          grid: {
            color: 'rgba(0,0,0,0.06)',
            drawTicks: false
          },
          ticks: {
            display: false // Values drawn on fixed Y-axis on the left
          },
          border: {
            display: false
          },
          beginAtZero: true
        }
      }
    },
    plugins: [{
      id: 'fixedYAxisSync',
      afterRender: function(chart) {
        syncFixedYAxis(chart);
      }
    }]
  });

  buildLegend(datasets);
  chartSubtitle.textContent = entry.name + ' · ' + rows.length + ' rows · ' + valueCols.length + ' series';
  statRows.textContent = rows.length;
  statCols.textContent = columns.length;
}

/* ─── Legend Builder ──────────────────────────────────────── */
function buildLegend(datasets) {
  chartLegend.style.display = 'flex';
  chartLegend.innerHTML = '';
  datasets.forEach(function(ds) {
    var item = document.createElement('div');
    item.className = 'legend-item';
    item.innerHTML =
      '<div class="legend-dot" style="background:' + ds.borderColor + ';"></div>' +
      '<span>' + ds.label + '</span>';
    chartLegend.appendChild(item);
  });
}

/* ─── Format Bytes ────────────────────────────────────────── */
function formatBytes(bytes) {
  if (!bytes) return '0 B';
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

/* ─── Re-draw Chart on Window Resize ──────────────────────── */
var resizeTimer;
window.addEventListener('resize', function() {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(function() {
    if (activeFileIndex >= 0 && uploadedFiles[activeFileIndex]) {
      renderChart(uploadedFiles[activeFileIndex], activeFileIndex);
    }
  }, 150);
});
